<?php

class Category_model extends CI_Model {

    public function insertData($table_name, $insert_data) {
        $this->db->insert($table_name, $insert_data);
        return $this->db->insert_id();
    }

    public function getRecords($table_name, $fields, $condition) {
        if ($fields == '') {
            $fields = '*';
        }
        $this->db->select($fields);
        $this->db->from($table_name);
        if ($condition != '' && count($condition) > 0) {
            $this->db->where($condition);
        }
        $result = $this->db->get();
        return $result->result_array();
    }

    public function getRecordsParent($table_name, $fields,$limit,$offset) {
        if ($fields == '') {
            $fields = '*';
        }
        $this->db->select($fields);
        $this->db->from($table_name);
        $this->db->where('parent_id is NULL', NULL, TRUE);
        if($limit!='') {
            $this->db->limit($limit,$offset);
        }
        $result = $this->db->get();
        return $result->result_array();
    }

}
