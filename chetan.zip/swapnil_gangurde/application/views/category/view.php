<?php
if (count($record) > 0) {
    foreach ($record as $k => $v) {
        ?>
        <tr>
            <td><?php echo ucwords($v['category_name']); ?></td>
            <td><?php echo $v['category_info']; ?></td>
            <td><img width="50" height="50" src="<?php echo base_url() . 'uploads/' . $v['image_name']; ?>" ></td>
            <td><?php echo $v['created_at']; ?></td>
        </tr>
        <?php
    }
} else {
    ?>
    <tr class="text-center">
        <td colspan="4" >No record found</td>
    </tr>
    <?php
}
?>