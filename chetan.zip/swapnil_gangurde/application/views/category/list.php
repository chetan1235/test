<?php
$msg = $this->session->userdata('msg_success');
$this->session->unset_userdata('msg_success');
$msg1 = $this->session->userdata('msg_error');
$this->session->unset_userdata('msg_error');
if ($msg != '') {
    ?>
    <div class="alert alert-success">
        <?php
        echo $msg;
        ?>
    </div>
    <?php
}
if ($msg1 != '') {
    ?>
    <div class="alert alert-danger">
        <?php echo $msg1; ?>
    </div>
<?php } ?>


<h2>Category List</h2>
<table class="table">
    <thead>
        <tr>
            <th>Category Name</th>
            <th>Category Image</th>
            <th>Added Date</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if (count($record) > 0) {
            foreach ($record as $k => $v) {
                ?>
                <tr>
                    <td><?php echo ucwords($v['category_name']); ?></td>
                    <td><img width="50" height="50" src="<?php echo base_url() . 'uploads/' . $v['image_name']; ?>" ></td>
                    <td><?php echo $v['created_at']; ?></td>
                    <td>
                        <a class="btn btn-success btn-sm add-sub-cat "   href="javascript:void(0);" data-toggle="modal" data-target="#sub_cat_model"   data-val="<?php echo $v['id']; ?>" data-name="<?php echo ucwords($v['category_name']); ?>">Add Sub Category</a>
                        <a class="btn btn-success btn-sm view-sub-cat "   href="javascript:void(0);" data-toggle="modal" data-target="#view_cat_model"   data-val="<?php echo $v['id']; ?>" >View Sub Category</a>
                    </td>
                </tr>
                <?php
            }
        }
        ?>


    </tbody>
    <tfoot>
        <tr>
            <td colspan="4" ><a href="javascript:void(0);"  class="btn btn-success btn-sm" data-toggle="modal" data-target="#addCategory"  title="Add Category">Add Category</a></td>
        </tr>
    </tfoot>
</table>
<div class="pagination">
    <?php
    if ($create_links) {
        echo $create_links;
    }
    ?>
</div>
<div id="addCategory" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add Category</h4>
            </div>
            <form method="post" name="add_category" id="add_category" action="<?php echo base_url(); ?>add-category"  enctype="multipart/form-data" >
                <div class="modal-body">
                    <div class="form-group" >
                        <label>Category Name</label>
                        <input type="text" class="form-control" name="cat_name" id="cat_name" />
                    </div>
                    <div class="form-group" >
                        <label>Category Image</label>
                        <input type="file" class="form-control" name="cat_img" id="cat_img" />
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success" >Add Category</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </form>

        </div>

    </div>
</div>
<div id="sub_cat_model" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add Sub-Category</h4>
            </div>
            <form method="post" name="sub_category" id="sub_category" action="<?php echo base_url(); ?>sub-category"  enctype="multipart/form-data" >

                <div class="modal-body">

                    <div class="form-group" >
                        <label>Parent Category Name</label>
                        <input type="text" class="form-control" id="parent_name" readonly="" />
                    </div>
                    <div class="form-group" >
                        <label>Sub Category Name</label>
                        <input type="text" class="form-control" name="cat_name" id="cat_name" />
                    </div>
                    <div class="form-group" >
                        <label>Sub Category Info</label>
                        <textarea class="form-control" name="cat_info" id="cat_info"  ></textarea>
                    </div>
                    <div class="form-group" >
                        <label>Sub Category Image</label>
                        <input type="file" class="form-control" name="cat_img" id="cat_img" />
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="parent_id" id="parent_id" />
                    <button type="submit" class="btn btn-success" >Add Sub Category</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>

    </div>
</div>
<div id="view_cat_model" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">View Sub-Category</h4>
            </div>
            <div class="modal-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Category Name</th>
                            <th>Category Info</th>
                            <th>Category Image</th>
                            <th>Added Date</th>
                        </tr>
                    </thead>
                    <tbody id="view_content"></tbody>

                </table> 

            </div>
            <div class="modal-footer">

                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
<script>
    $("#add_category").validate({
        errorElement: 'div',
        errorClass: 'text-danger',
        // Specify the validation rules
        rules: {
            cat_name: {
                required: true,
                remote: {
                    url: "<?php echo base_url() . 'check-cat-name' ?>",
                    type: "post",
                }
            },
            cat_img: {
                required: true,
                accept: "jpg|jpeg|png|ico|bmp|gif"
            }
        },
        // Specify the validation error messages
        messages: {
            cat_name: {
                required: 'Please category name',
                remote: 'Please enter unique category name'
            },
            cat_img: {
                required: 'Please select category image',
                accept: 'Please select image only'
            }
        },
        submitHandler: function (form) {
            form.submit();
        }
    });
    $("#sub_category").validate({
        errorElement: 'div',
        errorClass: 'text-danger',
        // Specify the validation rules
        rules: {
            cat_name: {
                required: true,
                remote: {
                    url: "<?php echo base_url() . 'check-cat-name' ?>",
                    type: "post",
                }
            },
            cat_info: {
                required: true,
            },
            cat_img: {
                required: true,
                accept: "jpg|jpeg|png|ico|bmp|gif"
            }
        },
        // Specify the validation error messages
        messages: {
            cat_name: {
                required: 'Please sub category name',
                remote: 'Please enter unique sub category name'
            },
            cat_info: {
                required: 'Please enter sub category information',
            },
            cat_img: {
                required: 'Please select category image',
                accept: 'Please select image only'
            }
        },
        submitHandler: function (form) {
            form.submit();
        }
    });

    $('.add-sub-cat').on('click', function () {
        var v = $(this).attr('data-val');
        var vname = $(this).attr('data-name');
        if (v) {
            $('#parent_id').val(v);
            $('#parent_name').val(vname);
//            $('#sub_cat_model').model('show');
        }
    });
    $('.view-sub-cat').on('click', function () {
        var v = $(this).attr('data-val');

        if (v) {
            $.ajax({
                url: '<?php echo base_url(); ?>get-sub-cat',
                type: 'post',
                dataType: 'json',
                data: {
                    cat_id: v
                },
                success: function (resp) {
                    $('#view_content').html(resp.view);
                }
            });
        }
    });
</script>

