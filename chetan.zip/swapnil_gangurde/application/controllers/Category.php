<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Category_model');
    }

    public function index($pg = '') {
        if ($pg == '') {
            $pg = '0';
        }
        $data['record'] = $this->Category_model->getRecordsParent('mst_category', '*', '', '');

        $this->load->library('pagination');

        $config['base_url'] = base_url() . 'category';
        $config['total_rows'] = count($data['record']);
        $config['per_page'] = 2;
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $data['record'] = $this->Category_model->getRecordsParent('mst_category', '*', $config['per_page'], $pg);

        $this->pagination->initialize($config);
        $data['create_links'] = $this->pagination->create_links();

        $data['site_title'] = 'Category List';
        $this->load->view('includes/header', $data);
        $this->load->view('category/list', $data);
        $this->load->view('includes/footer', $data);
    }

    public function checkName() {
        $name = $this->input->post('cat_name');
        $record = $this->Category_model->getRecords('mst_category', 'category_name', array('category_name' => strtolower($name)));
        if (count($record) > 0) {
            echo 'false';
        } else {
            echo 'true';
        }
    }

    public function addCategory() {
        if (count($_POST) > 0) {
            $image_name = '';
            if (isset($_FILES['cat_img']['name'])) {
                $path = $_FILES['cat_img']['name'];
                $ext = pathinfo($path, PATHINFO_EXTENSION);
                $config['file_name'] = time() . rand(11, 000) . '.' . $ext;
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size'] = 1000;
                $config['max_width'] = 1024;
                $config['max_height'] = 768;
                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('cat_img')) {
                    $error = array('error' => $this->upload->display_errors());
                    $this->session->set_userdata('msg_error', $error['error']);
                    redirect(base_url());
                } else {
                    $upload_data = array('upload_data' => $this->upload->data());

                    $image_name = $upload_data['upload_data']['file_name'];
                }
            } else {
                $this->session->set_userdata('msg_error', 'Please select image');
                redirect(base_url());
            }
            if ($image_name != '') {
                $insert_data = array(
                    'category_name' => strtolower($this->input->post('cat_name')),
                    'image_name' => $image_name,
                    'created_at' => date('Y-m-d H:i:s')
                );
                $last_id = $this->Category_model->insertData('mst_category', $insert_data);

                if ($last_id) {
                    $this->session->set_userdata('msg_success', 'Category added successfully');
                } else {
                    $this->session->set_userdata('msg_error', 'Please try again');
                }
                redirect(base_url());
            } else {
                $this->session->set_userdata('msg_error', 'Please select image');
                redirect(base_url());
            }
        } else {
            redirect(base_url());
        }
    }

    public function subCategory() {
        if (count($_POST) > 0) {
            $image_name = '';
            if (isset($_FILES['cat_img']['name'])) {
                $path = $_FILES['cat_img']['name'];
                $ext = pathinfo($path, PATHINFO_EXTENSION);
                $config['file_name'] = time() . rand(11, 000) . '.' . $ext;
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size'] = 1000;
                $config['max_width'] = 2024;
                $config['max_height'] = 768;
                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('cat_img')) {
                    $error = array('error' => $this->upload->display_errors());

                    $this->session->set_userdata('msg_error', $error['error']);
                    redirect(base_url());
                } else {
                    $upload_data = array('upload_data' => $this->upload->data());
                    $image_name = $upload_data['upload_data']['file_name'];
                }
            } else {
                $this->session->set_userdata('msg_error', 'Please select image');
                redirect(base_url());
            }
            if ($image_name != '') {
                $insert_data = array(
                    'category_name' => strtolower($this->input->post('cat_name')),
                    'category_info' => $this->input->post('cat_info'),
                    'image_name' => $image_name,
                    'parent_id' => $this->input->post('parent_id'),
                    'created_at' => date('Y-m-d H:i:s')
                );
                $last_id = $this->Category_model->insertData('mst_category', $insert_data);

                if ($last_id) {
                    $this->session->set_userdata('msg_success', 'Sub Category added successfully');
                } else {
                    $this->session->set_userdata('msg_error', 'Please try again');
                }
                redirect(base_url());
            } else {
                $this->session->set_userdata('msg_error', 'Please select image');
                redirect(base_url());
            }
        } else {
            redirect(base_url());
        }
    }

    public function getSubCategory() {
        $cat_id = $this->input->post('cat_id');
        $data['record'] = $this->Category_model->getRecords('mst_category', '*', array('parent_id' => $cat_id));
        $data['site_title'] = 'Category List';
        $content = $this->load->view('category/view', $data, true);
        print_r(json_encode(array('view' => $content)));
    }

}
